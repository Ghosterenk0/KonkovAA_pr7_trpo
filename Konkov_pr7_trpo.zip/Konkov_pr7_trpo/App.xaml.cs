﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace konkov_pr7_trpo
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App :Application
    {
    }

}

﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace konkov_pr7_trpo
{
    public class Pacient : INotifyPropertyChanged
    {
        private int _id;
        private string _surname = "";
        private string _name = "";
        private string _middleName = "";
        private string _brithday = "";
        private string _lastAppointment = "";
        private string _diagnosis = "";
        private string _recomendation = "";
        private string _lastDoctor = "";
        public int Id
        {
            get => _id;
            set
            {
                if (_id != value)
                {
                    _id = value;
                    OnPropertyChanged();
                }
            }
        }

        public string Surname
        {
            get => _surname;
            set
            {
                if (_surname != value)
                {
                    _surname = value;
                    OnPropertyChanged();
                }
            }
        }

        public string Name
        {
            get => _name;
            set
            {
                if (_name != value)
                {
                    _name = value;
                    OnPropertyChanged();
                }
            }
        }

        public string MiddleName
        {
            get => _middleName;
            set
            {
                if (_middleName != value)
                {
                    _middleName = value;
                    OnPropertyChanged();
                }
            }
        }

        public string Brithday
        {
            get => _brithday;
            set
            {
                if (_brithday != value)
                {
                    _brithday = value;
                    OnPropertyChanged();
                }
            }
        }

        public string LastAppointment
        {
            get => _lastAppointment;
            set
            {
                if (_lastAppointment != value)
                {
                    _lastAppointment = value;
                    OnPropertyChanged();
                }
            }
        }

        public string Diagnosis
        {
            get => _diagnosis;
            set
            {
                if (_diagnosis != value)
                {
                    _diagnosis = value;
                    OnPropertyChanged();
                }
            }
        }

        public string Recomendation
        {
            get => _recomendation;
            set
            {
                if (_recomendation != value)
                {
                    _recomendation = value;
                    OnPropertyChanged();
                }
            }
        }
        public string LastDoctor
        {
            get => _lastDoctor;
            set
            {
                if(_lastDoctor != value)
                {
                    _lastDoctor = value;
                    OnPropertyChanged();
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
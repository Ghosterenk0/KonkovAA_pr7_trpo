﻿using System;
using System.IO;
using System.Text.Json;
using System.Windows;

namespace konkov_pr7_trpo
{
    public partial class MainWindow : Window
    {
        private User currentDoctor = new User();
        private Pacient currentPatient = new Pacient();
        private Pacient searchPatient = new Pacient();
        private bool isDoctorActive = false;

        private int nextDoctorId = 10000;
        private int nextPatientId = 1000000;

        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;

            txtRegSurname.DataContext = currentDoctor;
            txtRegName.DataContext = currentDoctor;
            txtRegMiddleName.DataContext = currentDoctor;
            txtRegSpecialisation.DataContext = currentDoctor;
            txtRegPassword.DataContext = currentDoctor;

            txtAddName.DataContext = currentPatient;
            txtAddMiddleName.DataContext = currentPatient;
            txtAddSurname.DataContext = currentPatient;

            txtEditMiddleName.DataContext = currentPatient;
            txtEditName.DataContext = currentPatient;
            txtEditSurname.DataContext = currentPatient;

            txtDiagnosis.DataContext = currentPatient;
            txtRecommendations.DataContext = currentPatient;
            txtLastAppointment.DataContext = currentPatient;
        }

        private void SaveUser(User user)
        {
            try
            {
                string json = JsonSerializer.Serialize(user);
                string path = $"D_{user.Id}.json";
                File.WriteAllText(path, json);
                MessageBox.Show($"Доктор сохранен! ID: {user.Id}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private User LoadUser(int id)
        {
            try
            {
                string path = $"D_{id}.json";
                if (File.Exists(path))
                {
                    string json = File.ReadAllText(path);
                    return JsonSerializer.Deserialize<User>(json);
                }
            }
            catch { }
            return null;
        }

        private void SavePatient(Pacient patient)
        {
            try
            {
                string json = JsonSerializer.Serialize(patient);
                string path = $"P_{patient.Id}.json";
                File.WriteAllText(path, json);
                MessageBox.Show($"Пациент сохранен! ID: {patient.Id}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private Pacient LoadPatient(int id)
        {
            try
            {
                string path = $"P_{id}.json";
                if (File.Exists(path))
                {
                    string json = File.ReadAllText(path);
                    return JsonSerializer.Deserialize<Pacient>(json);
                }
            }
            catch { }
            return null;
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtRegSurname.Text))
            {
                MessageBox.Show("Введите фамилию!");
            }
            if (string.IsNullOrWhiteSpace(txtRegName.Text))
            {
                MessageBox.Show("Введите имя!");
            }
            if (string.IsNullOrWhiteSpace(txtRegSpecialisation.Text))
            {
                MessageBox.Show("Введите специальность!");
            }
            if (string.IsNullOrWhiteSpace(txtRegPassword.Text))
            {
                MessageBox.Show("Введите пароль!");
            }

            currentDoctor.Id = nextDoctorId;
            nextDoctorId++;
            SaveUser(currentDoctor);

            currentDoctor = new User();
            txtRegSurname.DataContext = currentDoctor;
            txtRegName.DataContext = currentDoctor;
            txtRegMiddleName.DataContext = currentDoctor;
            txtRegSpecialisation.DataContext = currentDoctor;
            txtRegPassword.DataContext = currentDoctor;

        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtLoginId.Text))
            {
                MessageBox.Show("Введите ID!");
            }
            if (string.IsNullOrWhiteSpace(txtLoginPassword.Text))
            {
                MessageBox.Show("Введите пароль!");
            }

            if (int.TryParse(txtLoginId.Text, out int doctorId))
            {
                User doctor = LoadUser(doctorId);
                if (doctor != null && doctor.Password == txtLoginPassword.Text)
                {
                    currentDoctor = doctor;
                    isDoctorActive = true;
                    MessageBox.Show($"Добро пожаловать, {doctor.Name}!");
                }
                else
                {
                    MessageBox.Show("Неверный ID или пароль!");
                }
            }
            else
            {
                MessageBox.Show("Введите корректный ID!");
            }
        }

        private void SearchPatientButton_Click(object sender, RoutedEventArgs e)
        {
            if (!isDoctorActive)
            {
                MessageBox.Show("Сначала войдите в систему!");
            }

            if (string.IsNullOrWhiteSpace(txtSearchPatientId.Text))
            {
                MessageBox.Show("Введите ID пациента!");
            }

            if (int.TryParse(txtSearchPatientId.Text, out int patientId))
            {
                Pacient patient = LoadPatient(patientId);
                if (patient != null)
                {
                    searchPatient = patient;

                    txtEditSurname.DataContext = searchPatient;
                    txtEditName.DataContext = searchPatient;
                    txtEditMiddleName.DataContext = searchPatient;
                    dpEditBirthday.DataContext = searchPatient;
                    txtLastAppointment.DataContext = searchPatient;
                    txtDiagnosis.DataContext = searchPatient;
                    txtRecommendations.DataContext = searchPatient;
                    MessageBox.Show("Пациент найден!");
                }
                else
                {
                    MessageBox.Show("Пациент не найден!");
                }
            }
            else
            {
                MessageBox.Show("Введите корректный ID пациента!");
            }
        }

        private void AddPatientButton_Click(object sender, RoutedEventArgs e)
        {
            if (!isDoctorActive)
            {
                MessageBox.Show("Сначала войдите в систему!");
            }

            if (string.IsNullOrWhiteSpace(txtAddSurname.Text))
            {
                MessageBox.Show("Введите фамилию пациента!");
            }
            if (string.IsNullOrWhiteSpace(txtAddName.Text))
            {
                MessageBox.Show("Введите имя пациента!");
            }

            currentPatient.Id = nextPatientId;
            nextPatientId++;
            currentPatient.LastAppointment = DateTime.Now.ToString("dd.MM.yyyy");

            SavePatient(currentPatient);

            currentPatient = new Pacient();
            txtAddSurname.DataContext = currentPatient;
            txtAddName.DataContext = currentPatient;
            txtAddMiddleName.DataContext = currentPatient;
            dpAddBirthday.DataContext = currentPatient;
        
        }

        private void UpdatePatientButton_Click(object sender, RoutedEventArgs e)
        {
            if (!isDoctorActive || searchPatient.Id == 0)
            {
                MessageBox.Show("Сначала найдите пациента!");
            }

            if (string.IsNullOrWhiteSpace(txtEditSurname.Text))
            {
                MessageBox.Show("Введите фамилию пациента!");
            }
            if (string.IsNullOrWhiteSpace(txtEditName.Text))
            {
                MessageBox.Show("Введите имя пациента!");
            }

            SavePatient(searchPatient);
            MessageBox.Show("Данные обновлены!");
        }

        private void ResetPatientButton_Click(object sender, RoutedEventArgs e)
        {
            if (searchPatient.Id == 0)
            {
                MessageBox.Show("Сначала найдите пациента!");
            }

            Pacient patient = LoadPatient(searchPatient.Id);
            if (patient != null)
            {
                searchPatient = patient;
                txtEditName.DataContext = searchPatient;
                txtEditMiddleName.DataContext = searchPatient;
                txtEditSurname.DataContext= searchPatient;
                MessageBox.Show("Данные сброшены!");
            }
        }
    }
}